#include <iostream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

using namespace std;
using namespace sf;




// resolutionX and resolutionY determine the rendering resolution.
const int resolutionX = 960;
const int resolutionY = 640;
const int boxPixelsX = 32;
const int boxPixelsY = 32;
const int gameRows = resolutionX / boxPixelsX; // Total rows on grid
const int gameColumns = resolutionY / boxPixelsY; // Total columns on grid


// Initializing GameGrid.
int gameGrid[gameRows][gameColumns] = {};

// Game States
enum GameState { MENU_STATE, LEVEL_SELECT_STATE, GAME_STATE, INSTRUCTIONS_STATE, EXIT_STATE };


// Functions
void drawMenu(RenderWindow& window, int& selectedOption);
void handleMenuInput(RenderWindow& window, int& selectedOption, GameState& currentState);
void drawLevelSelect(RenderWindow& window, int& selectedLevel);
void handleLevelSelectInput(RenderWindow& window, int& selectedLevel, GameState& currentState);
void drawInstructions(RenderWindow& window, GameState& currentState);
void runGame(
    int selectedLevel, RenderWindow& window, 
    float& player_x, float& player_y, Sprite& playerSprite, Texture& playerTexture,
    float& bullet_x, float& bullet_y, bool& bullet_exists, Sprite& bulletSprite, Clock& bulletClock,
    int& score, bool& gameOver, Clock& firingClock, const float firingDelay, 
    int spraysLeftInCan[], int& currentCan, const int spraysPerPart, const int spraysPerCan,
    string canImageFiles[], Font& font, Text& scoreText,
    RectangleShape& groundRectangle, const float playerSpeed, const float playerWidth,
    Sprite beeSprites[], bool beeIsActive[], bool beeDirection[],
    Sprite redBeeSprites[], bool redBeeIsActive[], bool redBeeDirection[],
    Sprite honeycombSprites[], bool honeycombActive[], const int honeycombCount,
    Clock& honeycombDestroyClock, const float honeycombDestroyDelay,
    Sprite& hummingbirdSprite, bool& hummingbirdActive, float& hummingbirdX, float& hummingbirdY,
    float& hummingbirdSpeedX, float& hummingbirdSpeedY, bool& hummingbirdIsSick, 
    Clock& hummingbirdSickClock, const float hummingbirdSickDuration,
    const int maxBees, const int maxRedBees,  int beeSpeed, const int redBeeSpeed,
    const int beeDescent, int flowerGrid[], Texture& flowerTexture, int& flowerCount,
    Clock beePauseClocks[], bool beeIsPaused[], float beePauseDurations[], 
    Clock beeDelayClocks[], float beeDelayDurations[], 
    Texture& honeycombTexture, Texture& redhoneycombTexture, bool beeIsHoneycomb[],
    bool redBeeIsHoneycomb[], Sound& fireSound, const int resolutionX, const int resolutionY,
    Texture& canTexture, Sprite spareCanSprites[],
    const int BEE_SPEED, const int RED_BEE_SPEED, const int BEE_DESCENT,GameState& currentState
);

void clearFlowers(int flowerGrid[], int& flowerCount);
void drawPlayer(RenderWindow& window, float& player_x, float& player_y, Sprite& playerSprite);
void moveBullet(float& bullet_y, bool& bullet_exists, Clock& bulletClock);
void drawBullet(RenderWindow& window, float& bullet_x, float& bullet_y, Sprite& bulletSprite);
void handlePlayerMovement(float& player_x, const float playerSpeed, const float playerWidth, int flowerGrid[]);
void updateBees(
    Sprite beeSprites[], bool beeIsActive[], bool beeDirection[],
    bool redBeeDirection[], bool redBeeIsActive[],
    const int maxBees, Sprite redBeeSprites[], const int maxRedBees,
    int beeSpeed, int redBeeSpeed, int beeDescent,
    int flowerGrid[], Texture& flowerTexture,int& flowerCount,
    const int gameRows, const int gameColumns, const int boxPixelsX,
    const int boxPixelsY, int& currentCan, int spraysLeftInCan[],
    bool& gameOver,Clock beePauseClocks[], bool beeIsPaused[], float beePauseDurations[], Clock beeDelayClocks[], float beeDelayDurations[] 
);
void checkBulletCollision(Sprite bulletSprite, float& bullet_x, float& bullet_y, bool& bullet_exists, Sprite beeSprites[], bool beeIsActive[], bool beeDirection[], bool redBeeIsActive[], Sprite redBeeSprites[], int& score, int maxBees, int maxRedBees,Texture& honeycombTexture,bool beeIsHoneycomb[],Texture& redhoneycombTexture,bool redBeeIsHoneycomb[]);
void handleHoneycombCollision(Sprite beeSprites[], bool beeIsActive[], bool beeDirection[],
                               Sprite redBeeSprites[], bool redBeeIsActive[], bool redBeeDirection[],
                               const int maxBees, const int maxRedBees, int beeDescent, bool redBeeIsHoneycomb[],bool beeIsHoneycomb[]) ;

void checkHoneycombBulletCollision(Sprite honeycombSprites[], bool honeycombActive[], 
                                   int honeycombCount, float& bullet_x, float& bullet_y, 
                                   bool& bullet_exists,bool beeIsActive[], bool beeDirection[] ,int maxBees,Sprite beeSprites[], int beeDescent);
void updateHummingbird(
    Sprite& hummingbirdSprite, bool& hummingbirdActive, 
    float& hummingbirdX, float& hummingbirdY, 
    float& hummingbirdSpeedX, float& hummingbirdSpeedY,
    bool& hummingbirdIsSick, Clock& hummingbirdSickClock, 
    const float hummingbirdSickDuration, int& points, 
    Sprite honeycombSprites[], bool honeycombActive[], 
    const int honeycombCount, const int resolutionX, 
    const int resolutionY, Clock& honeycombDestroyClock, 
    const float honeycombDestroyDelay
);

void handleHummingbirdBulletCollision(
    Sprite& hummingbirdSprite, bool& hummingbirdIsSick, 
    Clock& hummingbirdSickClock, Sprite bulletSprite, 
    float bullet_x, float bullet_y, bool& bullet_exists,float& hummingbirdX, float& hummingbirdY
) ;



int main() {
//ARRAY TO IMPORT TEXTURE OF SPRAY FILES
    string canImageFiles[7] = {
    "Textures/spray1.png", "Textures/spray2.png", "Textures/spray3.png","Textures/spray4.png","Textures/spray5.png","Textures/spray6.png", "Textures/spray7.png"
    };

//Green Rectangle AT BOTTOM
	RectangleShape groundRectangle(Vector2f(960, 64));
	groundRectangle.setPosition(0, (gameColumns - 2) * boxPixelsY);
	groundRectangle.setFillColor(Color::Green);    //FILL COLOR WITH GREEN
//SCORE
    int score = 0;
    bool gameOver = false; //GAME OVER
//SPRAY CANS
    int spraysPerPart = 8;
    const int spraysPerCan = 56; // Maximum sprays per can
    int currentCan = 0;          // Current spray can in use (0, 1, or 2)
    int spraysLeftInCan[3] = {spraysPerCan, spraysPerCan, spraysPerCan}; // Sprays left for each can    
//RED BEE
    const int RED_BEE_SPEED = 3;  // Red bees move faster
    const int maxRedBees =22;  // Number of Red Bees in the game
    Sprite redBees[maxRedBees];    // Red Bee array
    Sprite redBeeSprites[maxRedBees];
    bool redBeeIsActive[maxRedBees];
    bool redBeeIsHoneycomb[maxRedBees];
    int redBeeScoreValue[maxRedBees];
//REGULAR BEE
    const int BEE_SPEED = 1; 
    const int BEE_DESCENT = 48;
    const int maxBees = 5; // Maximum number of bees
    Sprite bees[maxBees];  // Array to hold bees

// Arrays for bee attributes
    Sprite beeSprites[maxBees];
    bool beeIsActive[maxBees];
    bool beeIsHoneycomb[maxBees];
    bool beeDirection[maxBees];
    bool redBeeDirection[maxRedBees];
    int beeScoreValue[maxBees];
//DELAY FIRING
    Clock firingClock;
    const float firingDelay = 0.7f;        // Delay in seconds between shots
    const float spacingFactor = 2.0f;      //Spacing between bees
//FLOWER    
int flowerCount = 0; // Tracks the number of flowers
    int flowerGrid[gameRows] = {0}; // 0: empty, 1: flower present
//RANDOM HONEY CPOMB
const int honeycombCount = 3;
Sprite honeycombSprites[honeycombCount];
bool honeycombActive[honeycombCount];

  //RANDOM PAAURSE OF THE BEE
  Clock beePauseClocks[maxBees]; // Clocks for each bee
bool beeIsPaused[maxBees] = {false}; // Pause states for bees
float beePauseDurations[maxBees] = {0.2f}; // Pause durations for bees
//dELAY BETEEEN THE PAUSE
Clock beeDelayClocks[maxBees];    // Clocks to manage delay between pauses
float beeDelayDurations[maxBees]; // Durations for the delay between pauses
//Huming bee
Clock honeycombDestroyClock;        // Tracks time since the last honeycomb destruction
const float honeycombDestroyDelay = 6.0f;  // 1.5 seconds between honeycomb destruction
Sprite hummingbirdSprite;
bool hummingbirdActive = true;
float hummingbirdX = 100.0f;
float hummingbirdY = 100.0f;
float hummingbirdSpeedX = 3.0f + (rand() % 3); // Randomized horizontal speed
float hummingbirdSpeedY = 3.0f + (rand() % 3); // Randomized vertical speed
bool hummingbirdIsSick = false;
Clock hummingbirdSickClock; // Tracks sickness duration
const float hummingbirdSickDuration = 1.0f; // 3 seconds of sickness



    
    const float playerSpeed = 2.0f; // Adjust this for desired movement speed
	srand(time(0));

	// Declaring RenderWindow.
	RenderWindow window(VideoMode(resolutionX, resolutionY), "Buzz Bombers", Style::Close | Style::Titlebar);

	// Used to position your window on every launch. Use according to your needs.
	window.setPosition(Vector2i(500, 200));

	// Initializing Background Music.
	Music bgMusic;
	if (!bgMusic.openFromFile("Music/Music3.ogg")) {
    cout << "Error: Could not load music file!" << endl;
	}
	bgMusic.setVolume(50);
	bgMusic.setLoop(true);
	bgMusic.play();

    

//////////////////////////////////////////////////////////////////////////////////
//                            Load Textures                                    //
////////////////////////////////////////////////////////////////////////////////

//Load Bee Texture
Texture beeTexture;
if (!beeTexture.loadFromFile("Textures/bee.png")) {
        cout << "Error: Could not load bee texture!" << endl;
        return 0;
    }

// Load Red Bee Texture
Texture redBeeTexture;
if (!redBeeTexture.loadFromFile("Textures/red_bee.png")) {
    cout << "Error: Could not load red bee texture!" << endl;
    return 0;
}

//Load Font for Display
Font font;
if (!font.loadFromFile("Fonts/Poppins.ttf")) {
    cout << "Error: Could not load font!" << endl;
    return 0;
}


//honeucomb texture
 Texture honeycombTexture;
if (!honeycombTexture.loadFromFile("Textures/honeycomb.png")) {
    cout << "Error: Could not load honeycomb texture!" << endl;
    return 0;
}


//redhoneucomb texture
 Texture redhoneycombTexture;
if (!redhoneycombTexture.loadFromFile("Textures/red_honeycomb.png")) {
    cout << "Error: Could not load honeycomb texture!" << endl;
    return 0;
}
Texture hummingbirdTexture;
if (!hummingbirdTexture.loadFromFile("Textures/hummingbird.png")) {
    std::cout << "Error: Could not load hummingbird texture!" << std::endl;
}

hummingbirdSprite.setTexture(hummingbirdTexture);
hummingbirdSprite.setScale(1.0f, 1.0f); // Adjust scale if needed (0.5x size)




//Load Bullet Textures
	Clock bulletClock;
	Texture bulletTexture;
	Sprite bulletSprite;
	bulletTexture.loadFromFile("Textures/bullet.png");
	bulletSprite.setTexture(bulletTexture);
	bulletSprite.setScale(3, 3);
	bulletSprite.setTextureRect(sf::IntRect(0, 0, boxPixelsX, boxPixelsY));
    if (!bulletTexture.loadFromFile("Textures/bullet.png")) {
    cout << "Error: Could not load Bullet texture!" << endl;
    return 0;
}

//Load Players Texture
	Texture playerTexture;
	Sprite playerSprite;
	playerTexture.loadFromFile("Textures/spray1.png");
	playerSprite.setTexture(playerTexture);
if (!playerTexture.loadFromFile("Textures/spray1.png")) {
    cout << "Error: Could not load SprayCan texture!" << endl;
    return 0;
}


//Load StockCan Textures
	Texture canTexture;
	Sprite spareCanSprites[2];
	canTexture.loadFromFile("Textures/spray1.png");


// Load flower texture
    Texture flowerTexture;
    if (!flowerTexture.loadFromFile("Textures/flower.png")) {
        cout << "Error: Could not load flower texture!" << endl;
        return 0;
    }

SoundBuffer fireSoundBuffer;  
Sound fireSound;              
if (!fireSoundBuffer.loadFromFile("Sounds/fire.wav")) {
    std::cout << "Error: Could not load fire sound!" << std::endl;
    return 0;
}
fireSound.setBuffer(fireSoundBuffer);  // Set the sound buffer to the sound object






/////////////////////////////////////////////////////////////////////////////
//                             Initialize                                 //
///////////////////////////////////////////////////////////////////////////
for (int i = 0; i < maxBees; ++i) {
    beeDelayDurations[i] = 4.0f + (rand() % 3); // Delay for 2-5 seconds
    beeDelayClocks[i].restart();               // Start the delay timer
}


//INITALZE REG_BEE
for (int i = 0; i < maxBees; ++i) {
    beeSprites[i].setTexture(beeTexture);
    
    if (i % 2 == 0) {           // Half of the bees start from the left side
        float gap = (resolutionX / 2 / (maxBees / 2 + 1))*spacingFactor; // Compute the gap between bees
        float startX = (i / 2 + 1) * gap; // Random position in the left quarter
        beeSprites[i].setPosition(startX, 32); // Top quarter of the screen
        beeDirection[i] = true; // Move to the right
    } else {
        float gap =( resolutionX / 2 / (maxBees / 2 + 1))*spacingFactor; // Compute the gap between bees
        float startX = resolutionX-(i / 2 + 1) * gap; // Random position in the left quarter
        beeSprites[i].setPosition(startX, 32); // Top quarter of the screen
        beeDirection[i] = false; // Move to the left
    }
    
    beeIsActive[i] = true;
    beeIsHoneycomb[i] = false;
    beeSprites[i].setScale(0.75f, 0.75f); // Scale the bees if needed
}

//INITIALIZE RED BWW
for (int i = 0; i < maxRedBees; ++i) {
    redBeeSprites[i].setTexture(redBeeTexture);
    
    if (i % 2 == 0) {     // Half of the bees start from the left side
        float gap = (resolutionX / 2 / (maxBees / 2 + 1))*spacingFactor; // Compute the gap between bees
        float startX = (i / 2 + 1) * gap; // Random position in the left quarter
        redBeeSprites[i].setPosition(startX, 32); // Top quarter of the screen
        redBeeDirection[i] = true; // Move to the right
    } else {
        float gap = (resolutionX / 2 / (maxBees / 2 + 1))*spacingFactor; // Compute the gap between bees
        float startX = resolutionX-(i / 2 + 1) * gap; // Random position in the left quarter
        redBeeSprites[i].setPosition(startX, 32); // Top quarter of the screen
        redBeeDirection[i] = false; // Move to the left
    }
    
    redBeeIsActive[i] = true;
    redBeeIsHoneycomb[i] = false;
    redBeeSprites[i].setScale(0.75f, 0.75f); // Scale the red bees if needed
}


//For ScoreBoard
Text scoreText("Score: 0", font, 30);
scoreText.setFillColor(Color::White);
scoreText.setPosition(10, 10);


// Initializing Player and Player Sprites.
	float player_x = (gameRows / 2) * boxPixelsX;
	float player_y = (gameColumns - 4) * boxPixelsY;

    
// Initializing Bullet and Bullet Sprites
	float bullet_x = player_x;
	float bullet_y = player_y;
	bool bullet_exists = false;

    

//For Stock Cans
	for (int i = 0; i < 2; ++i) {
    	spareCanSprites[i].setTexture(canTexture);
    	spareCanSprites[i].setScale(0.5, 0.5); // Scale for smaller size
    	spareCanSprites[i].setPosition(10 + i * 60, resolutionY - 60); // Position in lower-left corner
	}
	
    const float playerWidth = playerSprite.getTextureRect().width * playerSprite.getScale().x; // Account for scaling
//RANDOM Honey comb
// RANDOM Honeycomb
for (int i = 0; i < honeycombCount; ++i) {
    honeycombSprites[i].setTexture(honeycombTexture);
    honeycombSprites[i].setScale(1.0f, 1.0f);

    // Set random X position within the screen width
    float xPosition = rand() % (resolutionX - 50);  // Random X within screen bounds

    // Restrict Y position to the top half of the game screen
    float yPosition = rand() % (resolutionY / 2 - 50); // Random Y in the top half

    honeycombSprites[i].setPosition(xPosition, yPosition);
    honeycombActive[i] = true;
}

    

    // Menu Variables
    GameState currentState = MENU_STATE;
    int selectedOption = 0; // Tracks selected menu option
    int selectedLevel = 0;  // Tracks selected level

    while (window.isOpen()) {
        window.clear(Color(50, 50, 50)); // Background color

        // Menu State Management
        switch (currentState) {
            case MENU_STATE:
                drawMenu(window, selectedOption);
                handleMenuInput(window, selectedOption, currentState);
                break;

            case LEVEL_SELECT_STATE:
                drawLevelSelect(window, selectedLevel);
                handleLevelSelectInput(window, selectedLevel, currentState);
                break;

            case GAME_STATE:
  runGame(
    selectedLevel, window, 
    player_x, player_y, playerSprite, playerTexture,
    bullet_x, bullet_y, bullet_exists, bulletSprite, bulletClock,
    score, gameOver, firingClock, firingDelay,
    spraysLeftInCan, currentCan, spraysPerPart, spraysPerCan,
    canImageFiles, font, scoreText,
    groundRectangle, playerSpeed, playerWidth,
    beeSprites, beeIsActive, beeDirection,
    redBeeSprites, redBeeIsActive, redBeeDirection,
    honeycombSprites, honeycombActive, honeycombCount,
    honeycombDestroyClock, honeycombDestroyDelay,
    hummingbirdSprite, hummingbirdActive, hummingbirdX, hummingbirdY,
    hummingbirdSpeedX, hummingbirdSpeedY, hummingbirdIsSick, 
    hummingbirdSickClock, hummingbirdSickDuration,
    maxBees, maxRedBees, BEE_SPEED, RED_BEE_SPEED,
    BEE_DESCENT, flowerGrid, flowerTexture, flowerCount,
    beePauseClocks, beeIsPaused, beePauseDurations, 
    beeDelayClocks, beeDelayDurations, 
    honeycombTexture, redhoneycombTexture, beeIsHoneycomb,
    redBeeIsHoneycomb, fireSound, resolutionX, resolutionY,
    canTexture, spareCanSprites,
    BEE_SPEED, RED_BEE_SPEED, BEE_DESCENT,
    currentState
);



                currentState = MENU_STATE; // Return to menu after the game ends
                break;

            case INSTRUCTIONS_STATE:
                drawInstructions(window, currentState);
                break;

            case EXIT_STATE:
                window.close();
                break;
        }

        window.display();
    }

    return 0;
}

// Main Menu Display
void drawMenu(RenderWindow& window, int& selectedOption) {
    Font font;
    if (!font.loadFromFile("Fonts/Poppins.ttf")) {
        cout << "Error loading font!" << endl;
        return;
    }

    Text title("Buzz Bombers", font, 50);
    title.setFillColor(Color::White);
    title.setPosition(resolutionX / 2 - title.getGlobalBounds().width / 2, 100);

    string options[] = { "Start Game", "Choose Level", "Instructions", "Exit" };
    Text menuItems[4];

    for (int i = 0; i < 4; i++) {
        menuItems[i].setFont(font);
        menuItems[i].setString(options[i]);
        menuItems[i].setCharacterSize(30);
        menuItems[i].setPosition(resolutionX / 2 - menuItems[i].getGlobalBounds().width / 2, 250 + i * 50);
        menuItems[i].setFillColor(i == selectedOption ? Color::Yellow : Color::White);
        window.draw(menuItems[i]);
    }

    window.draw(title);
}

// Main Menu Input
void handleMenuInput(RenderWindow& window, int& selectedOption, GameState& currentState) {
    Event event;
    while (window.pollEvent(event)) {
        if (event.type == Event::Closed) {
            currentState = EXIT_STATE;
        }

        if (event.type == Event::KeyPressed) {
            if (event.key.code == Keyboard::Up) {
                selectedOption = (selectedOption - 1 + 4) % 4;
            } else if (event.key.code == Keyboard::Down) {
                selectedOption = (selectedOption + 1) % 4;
            } else if (event.key.code == Keyboard::Enter) {
                switch (selectedOption) {
                    case 0: currentState = GAME_STATE; break; // Start Game
                    case 1: currentState = LEVEL_SELECT_STATE; break; // Level Select
                    case 2: currentState = INSTRUCTIONS_STATE; break; // Instructions
                    case 3: currentState = EXIT_STATE; break; // Exit
                }
            }
        }
    }
}

// Level Select Display
void drawLevelSelect(RenderWindow& window, int& selectedLevel) {
    Font font;
    if (!font.loadFromFile("Fonts/Poppins.ttf")) {
        cout << "Error loading font!" << endl;
        return;
    }

    Text title("Select Level", font, 50);
    title.setFillColor(Color::White);
    title.setPosition(resolutionX / 2 - title.getGlobalBounds().width / 2, 100);

    string levels[] = { "Level 1: Easy", "Level 2: Medium", "Level 3: Hard" };
    Text levelItems[3];

    for (int i = 0; i < 3; i++) {
        levelItems[i].setFont(font);
        levelItems[i].setString(levels[i]);
        levelItems[i].setCharacterSize(30);
        levelItems[i].setPosition(resolutionX / 2 - levelItems[i].getGlobalBounds().width / 2, 250 + i * 50);
        levelItems[i].setFillColor(i == selectedLevel ? Color::Yellow : Color::White);
        window.draw(levelItems[i]);
    }

    window.draw(title);
}

// Level Select Input
void handleLevelSelectInput(RenderWindow& window, int& selectedLevel, GameState& currentState) {
    Event event;
    while (window.pollEvent(event)) {
        if (event.type == Event::Closed) {
            currentState = EXIT_STATE;
        }

        if (event.type == Event::KeyPressed) {
            if (event.key.code == Keyboard::Up) {
                selectedLevel = (selectedLevel - 1 + 3) % 3;
            } else if (event.key.code == Keyboard::Down) {
                selectedLevel = (selectedLevel + 1) % 3;
            } else if (event.key.code == Keyboard::Enter) {
                currentState = GAME_STATE;
            } else if (event.key.code == Keyboard::Escape) {
                currentState = MENU_STATE;
            }
        }
    }
}

// Instructions Display
void drawInstructions(RenderWindow& window, GameState& currentState) {
    Font font;
    if (!font.loadFromFile("Fonts/Poppins.ttf")) {
        cout << "Error loading font!" << endl;
        return;
    }

    Text title("Instructions", font, 50);
    title.setFillColor(Color::White);
    title.setPosition(resolutionX / 2 - title.getGlobalBounds().width / 2, 100);

    Text instructions(
        "Use Arrow Keys to Move.\n"
        "Press Space to Shoot.\n"
        "Clear all bees to win!\n\n"
        "Press ESC to return to the menu.",
        font, 30
    );
    instructions.setFillColor(Color::White);
    instructions.setPosition(50, 200);

    window.draw(title);
    window.draw(instructions);

    Event event;
    while (window.pollEvent(event)) {
        if (event.type == Event::KeyPressed && event.key.code == Keyboard::Escape) {
            currentState = MENU_STATE;
        }
    }
}

// Game Logic with Level Conditions
void runGame(
    int selectedLevel, RenderWindow& window, 
    float& player_x, float& player_y, Sprite& playerSprite, Texture& playerTexture,
    float& bullet_x, float& bullet_y, bool& bullet_exists, Sprite& bulletSprite, Clock& bulletClock,
    int& score, bool& gameOver, Clock& firingClock, const float firingDelay, 
    int spraysLeftInCan[], int& currentCan, const int spraysPerPart, const int spraysPerCan,
    string canImageFiles[], Font& font, Text& scoreText,
    RectangleShape& groundRectangle, const float playerSpeed, const float playerWidth,
    Sprite beeSprites[], bool beeIsActive[], bool beeDirection[],
    Sprite redBeeSprites[], bool redBeeIsActive[], bool redBeeDirection[],
    Sprite honeycombSprites[], bool honeycombActive[], const int honeycombCount,
    Clock& honeycombDestroyClock, const float honeycombDestroyDelay,
    Sprite& hummingbirdSprite, bool& hummingbirdActive, float& hummingbirdX, float& hummingbirdY,
    float& hummingbirdSpeedX, float& hummingbirdSpeedY, bool& hummingbirdIsSick, 
    Clock& hummingbirdSickClock, const float hummingbirdSickDuration,
    const int maxBees, const int maxRedBees,  int beeSpeed, const int redBeeSpeed,
    const int beeDescent, int flowerGrid[], Texture& flowerTexture, int& flowerCount,
    Clock beePauseClocks[], bool beeIsPaused[], float beePauseDurations[], 
    Clock beeDelayClocks[], float beeDelayDurations[], 
    Texture& honeycombTexture, Texture& redhoneycombTexture, bool beeIsHoneycomb[],
    bool redBeeIsHoneycomb[], Sound& fireSound, const int resolutionX, const int resolutionY,
    Texture& canTexture, Sprite spareCanSprites[],
    const int BEE_SPEED, const int RED_BEE_SPEED, const int BEE_DESCENT,GameState& currentState
){
    
     

    cout << "Running Level " << selectedLevel + 1 << " with Bee Speed: " << beeSpeed
         << endl;

    // Game logic here (integrate your existing gameplay mechanics)
    while (window.isOpen()) {
        Event e;
    while (window.pollEvent(e)) {
        if (e.type == Event::Closed) {
            currentState = MENU_STATE;
return;
        }
    }



// Handle player movement
handlePlayerMovement(player_x, playerSpeed, playerWidth, flowerGrid);

//Game Over
if (gameOver) {
    // Display "Game Over" message
    Text gameOverText("Game Over!", font, 50);
    gameOverText.setFillColor(Color::Red);
    gameOverText.setPosition(resolutionX / 2 - 150, resolutionY / 2);
    window.draw(gameOverText);
    window.display();
    sf::sleep(sf::seconds(2));
    currentState = MENU_STATE;
return;
}
// Handle shooting with Spacebar
if (Keyboard::isKeyPressed(Keyboard::Space) && !bullet_exists && spraysLeftInCan[currentCan] > 0) {
       
//For Delay Between Each Fire
if (firingClock.getElapsedTime().asSeconds() >= firingDelay) {
        bullet_exists = true;
        bullet_x = player_x + (playerSprite.getTextureRect().width * playerSprite.getScale().x / 2) - (bulletSprite.getTextureRect().width * bulletSprite.getScale().x / 4); // Center the bullet
        bullet_y = player_y;
        spraysLeftInCan[currentCan]--;       
         // Play firing sound
        fireSound.play();
        // Reset firing clock
        firingClock.restart();
}



    // Determine which part of the can we are on
        int spraysUsed = spraysPerCan - spraysLeftInCan[currentCan];
        int textureIndex = spraysUsed / spraysPerPart; // Calculate texture index (0 to 6)

    // Update texture of the current spray can in use
        if (textureIndex < 7) { // Prevent out-of-bounds errors
            playerTexture.loadFromFile(canImageFiles[textureIndex]);
        }

    // Switch to the next can if the current one is empty
    if (spraysLeftInCan[currentCan] == 0 && currentCan < 2) {
        currentCan++;
        playerTexture.loadFromFile(canImageFiles[0]); // Reset the new can to spray1.png
    }
    
	std::cout << "Sprays Used: " << spraysUsed << ", Texture Index: " << textureIndex << ", Sprays Left in Current Can: " << spraysLeftInCan[currentCan] << std::endl;

}


//Sprays Ends Validate
	if (currentCan == 2 && spraysLeftInCan[currentCan] == 0) {
    gameOver=true;
    }

if (bullet_exists == true) {
        moveBullet(bullet_y, bullet_exists, bulletClock);
        drawBullet(window, bullet_x, bullet_y, bulletSprite);
} else {
        bullet_x = player_x;
        bullet_y = player_y;
}

//FOR SCORE
    scoreText.setString("Score: " + to_string(score));
    window.draw(scoreText);
    drawPlayer(window, player_x, player_y, playerSprite);
    window.draw(groundRectangle);


//For SpareCans
for (int i = 0; i < 2; ++i) {
    if (currentCan <= i) { // Only draw unused cans
        canTexture.loadFromFile("Textures/spray1.png"); // Stock cans always use spray1.png
        spareCanSprites[i].setTexture(canTexture);
		spareCanSprites[i].setScale(0.9f, 0.9f); // Increase size (0.9times the original size)
        window.draw(spareCanSprites[i]);
    }
}



    ///////////////////////////////////////////////////////////////
   //               Call Your Functions Here                    //
  ///////////////////////////////////////////////////////////////

//update Bees
updateBees(beeSprites, beeIsActive, beeDirection, redBeeDirection,redBeeIsActive, maxBees, redBeeSprites, maxRedBees,BEE_SPEED, RED_BEE_SPEED, BEE_DESCENT, flowerGrid, flowerTexture,flowerCount,gameRows, gameColumns, boxPixelsX, boxPixelsY, currentCan, spraysLeftInCan, gameOver,beePauseClocks, beeIsPaused, beePauseDurations,beeDelayClocks, beeDelayDurations );

   
handleHoneycombCollision(beeSprites, beeIsActive, beeDirection, redBeeSprites, redBeeIsActive, redBeeDirection, maxBees, maxRedBees, BEE_DESCENT, redBeeIsHoneycomb,beeIsHoneycomb);
updateHummingbird(
    hummingbirdSprite, hummingbirdActive, 
    hummingbirdX, hummingbirdY, 
    hummingbirdSpeedX, hummingbirdSpeedY, 
    hummingbirdIsSick, hummingbirdSickClock, 
    hummingbirdSickDuration, score, 
    honeycombSprites, honeycombActive, 
    honeycombCount, resolutionX, resolutionY, 
    honeycombDestroyClock, honeycombDestroyDelay
);



handleHummingbirdBulletCollision(hummingbirdSprite, hummingbirdIsSick, 
                                  hummingbirdSickClock, bulletSprite, 
                                  bullet_x, bullet_y, bullet_exists,hummingbirdX, hummingbirdY);
checkHoneycombBulletCollision(honeycombSprites, honeycombActive, honeycombCount,bullet_x, bullet_y, bullet_exists,beeIsActive, beeDirection, maxBees, beeSprites, BEE_DESCENT);

// Check For Collision Of bullet and Bees    
if (bullet_exists) {
    checkBulletCollision(bulletSprite, bullet_x, bullet_y, bullet_exists, beeSprites, beeIsActive, beeDirection, redBeeIsActive, redBeeSprites, score, maxBees, maxRedBees,honeycombTexture,beeIsHoneycomb,redhoneycombTexture,redBeeIsHoneycomb);
}
 
////////////////////////////////////////////////////////////////////////////////
//                  Rendering                                                //
//////////////////////////////////////////////////////////////////////////////



for (int i = 0; i < maxBees; ++i) {
    if (beeIsActive[i] || beeIsHoneycomb[i]) { // Draw both active bees and honeycombs
        window.draw(beeSprites[i]);  // Access bee sprite
    }
    
}

for (int i = 0; i < maxRedBees; ++i) {
    if (redBeeIsActive[i] || redBeeIsHoneycomb[i]) { // Draw both active and honeycomb red bees
        window.draw(redBeeSprites[i]);  // Access red bee sprite
    }
}

for (int i = 0; i < honeycombCount; ++i) {
    if (honeycombActive[i]) {
        window.draw(honeycombSprites[i]);
    }
}

// Render player
playerSprite.setPosition(player_x, player_y); // Update player position
window.draw(playerSprite);


// Draw flowers on the green rectangle
for (int i = 0; i < gameRows; ++i) {
    if (flowerGrid[i] == 1) {
        // Flower by yellow bee
        Sprite flowerSprite(flowerTexture);
        flowerSprite.setScale(1.3f, 1.3f);
        flowerSprite.setPosition(i * boxPixelsX, (gameColumns - 3) * boxPixelsY - 5);
        window.draw(flowerSprite);
    } else if (flowerGrid[i] == 2) {
        // Flower by red bee
        Sprite redFlowerSprite(flowerTexture); 
        redFlowerSprite.setScale(1.3f, 1.3f);
        redFlowerSprite.setPosition(i * boxPixelsX, (gameColumns - 3) * boxPixelsY - 5);
        window.draw(redFlowerSprite);
    }
}

    window.draw(hummingbirdSprite); 
    window.display();
    window.clear(sf::Color(135, 206, 235));
}
}




void clearFlowers(int flowerGrid[], int& flowerCount) {
    for (int i = 0; i < gameRows; ++i) {
        flowerGrid[i] = 0; // Reset grid
    }
    flowerCount = 0; // Reset count
}


void resolveOverlap(float& player_x, float playerWidth, int flowerGrid[]) {
    int playerColumn = player_x / boxPixelsX;           // Current column of the player
    int playerLeftColumn = playerColumn - 1;            // Left neighboring column
    int playerRightColumn = playerColumn + 1;           // Right neighboring column

    // Check for overlap
    if (flowerGrid[playerColumn] != 0) {
        // Look for the nearest free space to the left
        for (int i = playerColumn - 1; i >= 0; --i) {
            if (flowerGrid[i] == 0) { // Free column found
                player_x = i * boxPixelsX; // Move to this column
                return;
            }
        }

        // If no free space to the left, look for free space to the right
        for (int i = playerColumn + 1; i < gameRows; ++i) {
            if (flowerGrid[i] == 0) { // Free column found
                player_x = i * boxPixelsX; // Move to this column
                return;
            }
        }
    }
}



void drawPlayer(RenderWindow& window, float& player_x, float& player_y, Sprite& playerSprite) {
	playerSprite.setPosition(player_x, player_y);
	window.draw(playerSprite);
}


void moveBullet(float& bullet_y, bool& bullet_exists, Clock& bulletClock) {
	if (bulletClock.getElapsedTime().asMilliseconds() < 20)
		return;

	bulletClock.restart();
	bullet_y -= 40;
	if (bullet_y < -32)
		bullet_exists = false;
}


void drawBullet(sf::RenderWindow& window, float& bullet_x, float& bullet_y, Sprite& bulletSprite) {
	bulletSprite.setPosition(bullet_x, bullet_y);
	window.draw(bulletSprite);
}


void handlePlayerMovement(float& player_x, const float playerSpeed, const float playerWidth, int flowerGrid[]) {
    int playerColumn = player_x / boxPixelsX; // Determine player's grid position
    int playerLeftColumn = player_x / boxPixelsX;                         // Left edge of the player
    int playerRightColumn = (player_x + playerWidth) / boxPixelsX;        // Right edge of the player

    // Check for left movement
   if (Keyboard::isKeyPressed(Keyboard::Left)) {
        // Check if there's space to move left and no flower blocking
        if (playerLeftColumn > -20 && flowerGrid[playerLeftColumn - 1] == 0) {
            player_x -= playerSpeed; // Move left
            if (player_x < 0) // Prevent going off the left boundary
                player_x = 0;}
         else if (flowerGrid[playerLeftColumn - 1] == 1) { // Flower blocks movement
            // Stop player at the current position
            player_x = playerLeftColumn * boxPixelsX; 
        }
        
    }

    // Check for right movement
    if (Keyboard::isKeyPressed(Keyboard::Right)) {
        if (playerColumn < gameRows - 1 && flowerGrid[playerColumn +2] == 0) { // Ensure no flower in the next column to the right
            player_x += playerSpeed;
            if (player_x > resolutionX - playerWidth) // Prevent going off the right boundary
                player_x = resolutionX - playerWidth;
        }
        else if (flowerGrid[playerRightColumn ] == 1) { // Flower present
            player_x -= boxPixelsX; // Push player to the left
        }
        
    }


    for (int col = playerLeftColumn; col <= playerRightColumn; ++col) {
        if (flowerGrid[col] == 1) { // Overlap detected
            // Move player to the nearest empty column
            if (col > 0 && flowerGrid[col - 1] == 0) {
                player_x -= boxPixelsX; // Push left
                break;
            } else if (col < gameRows  && flowerGrid[col + 5] == 0) {
                player_x += boxPixelsX; // Push right
                break;
            }
        }
    }
    // Resolve overlap if any
    resolveOverlap(player_x, playerWidth, flowerGrid);
}



void updateBees(
    Sprite beeSprites[], bool beeIsActive[], bool beeDirection[],
    bool redBeeDirection[], bool redBeeIsActive[],
    const int maxBees, Sprite redBeeSprites[], const int maxRedBees,
    int beeSpeed, int redBeeSpeed, int beeDescent,
    int flowerGrid[], Texture& flowerTexture,int& flowerCount,
    const int gameRows, const int gameColumns, const int boxPixelsX,
    const int boxPixelsY, int& currentCan, int spraysLeftInCan[],
    bool& gameOver,Clock beePauseClocks[], bool beeIsPaused[], float beePauseDurations[], Clock beeDelayClocks[], float beeDelayDurations[] 
){
    const float leftBoundary = 28;
    const float rightBoundary = resolutionX +10 ;
    const float UPPER_BOUNDARY = 20;
 


    // Update normal bees
    for (int i = 0; i < maxBees; ++i) {
        if (!beeIsActive[i]) continue;


         // Handle pausing
        if (beeIsPaused[i]) {
            // If the pause duration has elapsed, resume movement
            if (beePauseClocks[i].getElapsedTime().asSeconds() >= beePauseDurations[i]) {
                beeIsPaused[i] = false; // Resume movement
                beeDelayClocks[i].restart(); // Start delay clock for the next pause
            } else {
                continue; // Skip movement while paused
            }
        }

        // Only consider pausing if the delay duration has elapsed
        if (beeDelayClocks[i].getElapsedTime().asSeconds() >= beeDelayDurations[i]) {
            // Randomly decide to pause the bee
            if (rand() % 1000 < 5) { // ~0.5% chance per frame
                beeIsPaused[i] = true;
                beePauseDurations[i] = 1.0f + (rand() % 3); // Pause for 1-3 seconds
                beePauseClocks[i].restart(); // Start the pause timer
                continue; // Skip this update cycle
            }
        }





            //CHECK FOR UPPER BOUNDARY
        if (beeSprites[i].getPosition().y < UPPER_BOUNDARY) {
            beeSprites[i].setPosition(beeSprites[i].getPosition().x, UPPER_BOUNDARY);
        }

        // Move bee horizontally
        float moveDirection=-1.0f;
        if(beeDirection[i]){

         moveDirection =   1.0f ;    // True = right

        }
       


        beeSprites[i].move(moveDirection * beeSpeed, 0);

        // Flip texture based on direction
        if (beeDirection[i]) {

            beeSprites[i].setScale(-0.75f, 0.75f); // Facing left
        } else {
            beeSprites[i].setScale(0.75f, 0.75f); // Facing right
        }
        beeSprites[i].setOrigin(beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x / 2.f, beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y / 2.f);

        // Check boundaries and reverse direction
        float beeLeft = beeSprites[i].getPosition().x-20;
        float beeRight = beeSprites[i].getPosition().x + beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x+72;

        if ((beeDirection[i] && beeRight >= rightBoundary) || (!beeDirection[i] && beeLeft <= leftBoundary)) {
            beeSprites[i].move(0, beeDescent);
            beeDirection[i] = !beeDirection[i]; // Reverse direction
        }

        

    }

    //////////////////////////////
    //////   RED BEE      ///////
    ////////////////////////////
    for (int i = 0; i < maxRedBees; ++i) {
        if (!redBeeIsActive[i]) continue;

        float moveDirection=-1.0f;
        if(redBeeDirection[i]){
         moveDirection =   1.0f ;    // True = right
        }
        redBeeSprites[i].move(moveDirection * redBeeSpeed, 0);

        // Flip texture based on direction
        if (redBeeDirection[i]) {
            redBeeSprites[i].setScale(-0.75f, 0.75f); // Facing left
        } else {
            redBeeSprites[i].setScale(0.75f, 0.75f); // Facing right
        }
        redBeeSprites[i].setOrigin(redBeeSprites[i].getTextureRect().width * redBeeSprites[i].getScale().x / 2.f, redBeeSprites[i].getTextureRect().height * redBeeSprites[i].getScale().y / 2.f);

        // Check boundaries and reverse direction
        float redBeeLeft = redBeeSprites[i].getPosition().x;
        float redBeeRight = redBeeSprites[i].getPosition().x + redBeeSprites[i].getTextureRect().width * redBeeSprites[i].getScale().x+64;

        if ((redBeeDirection[i] && redBeeRight >= rightBoundary) || (!redBeeDirection[i] && redBeeLeft <= leftBoundary)) {
            redBeeSprites[i].move(0, beeDescent);
            redBeeDirection[i] = !redBeeDirection[i]; // Reverse direction
        } 
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Check for bee collision with the green rectangle
///////////////////////////////////////////////////////////////////////////////////////////////////////////    
for (int i = 0; i < maxBees; ++i) {
    if (!beeIsActive[i]) continue;

    float beeBottom = beeSprites[i].getPosition().y + beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y;
    if (beeBottom >= (gameColumns - 2) * boxPixelsY) {
        int beeColumn = beeSprites[i].getPosition().x / boxPixelsX;

        // Decide placement logic: Sequential or Random
        if (rand() % 100 < 70) { // 70% chance for sequential placement
            int startColumn = beeDirection[i] ? 0 : gameRows - 1; // Left or Right Start
            int step = beeDirection[i] ? 1 : -1; // Forward or Backward
            for (int j = startColumn; (j >= 0 && j < gameRows); j += step) {
                if (flowerGrid[j] == 0) {
                    flowerGrid[j] = 1;
                    flowerCount++;     // Increment flower count
                    cout<<"Count Yellow: "<<flowerCount<<endl;
            if (flowerCount >= 30) {
                if (currentCan < 3 && spraysLeftInCan[currentCan] > 0) {
                    spraysLeftInCan[currentCan]--; // Use a spare can
                    clearFlowers(flowerGrid, flowerCount); // Clear all flowers
                    currentCan++; // Move to the next can (if applicable)
                } else {
                    gameOver = true; // Trigger game over if no cans are left
                }
            }


                    break;
                }
            }
        } else { // 30% chance for random placement
            while (true) {
                int randomColumn = rand() % gameRows;
                if (flowerGrid[randomColumn] == 0) {
                    flowerGrid[randomColumn] = 1;
                    flowerCount++;     // Increment flower count
                    cout<<"Count Yellow: "<<flowerCount<<endl;
            if (flowerCount >= 30) {
                if (currentCan < 3 && spraysLeftInCan[currentCan] > 0) {
                    spraysLeftInCan[currentCan]--; // Use a spare can
                    clearFlowers(flowerGrid, flowerCount); // Clear all flowers
                    currentCan++; // Move to the next can (if applicable)
                } else {
                    gameOver = true; // Trigger game over if no cans are left
                }
            }
                    break;
                }
            }
        }

        
        beeIsActive[i] = false;
    }
}


/////////////////////////////////////////////////////RED BEES///////////////////////////////////////////
for (int i = 0; i < maxRedBees; ++i) {
    if (!redBeeIsActive[i]) continue;
    float redBeeBottom = redBeeSprites[i].getPosition().y + redBeeSprites[i].getTextureRect().height * redBeeSprites[i].getScale().y;
    if (redBeeBottom >= (gameColumns - 2) * boxPixelsY) {
        int redBeeColumn = redBeeSprites[i].getPosition().x / boxPixelsX;

        // Decide placement logic: Sequential or Random
        if (rand() % 100 < 70) { // 70% chance for sequential placement
            int startColumn = redBeeDirection[i] ? 0 : gameRows - 1; // Left or Right Start
            int step = redBeeDirection[i] ? 1 : -1; // Forward or Backward
            for (int j = startColumn; (j >= 0 && j < gameRows); j += step) {
                if (flowerGrid[j] == 0) {
                    flowerGrid[j] = 2; // Mark flower placement by red bee
                    flowerCount++;
                    cout<<"Count Red: "<<flowerCount<<endl;
            if (flowerCount >= 30) {
                if (currentCan < 3 && spraysLeftInCan[currentCan] > 0) {
                spraysLeftInCan[currentCan]--; // Use a spare can
                clearFlowers(flowerGrid, flowerCount); // Clear all flowers
                currentCan++; // Move to the next can (if applicable)
                } else {
                gameOver = true; 
                }
            }        
                    
                    
                    
                    break;
                }
            }
        } else { // 30% chance for random placement
            while (true) {
                int randomColumn = rand() % gameRows;
                if (flowerGrid[randomColumn] == 0) {
                    flowerGrid[randomColumn] = 2; // Mark flower placement by red bee
                    flowerCount++;
                    cout<<"Count Red: "<<flowerCount<<endl;
            if (flowerCount >= 30) {
                if (currentCan < 3 && spraysLeftInCan[currentCan] > 0) {
                spraysLeftInCan[currentCan]--; // Use a spare can
                clearFlowers(flowerGrid, flowerCount); // Clear all flowers
                currentCan++; // Move to the next can (if applicable)
                } else {
                gameOver = true; // Trigger game over if no cans are left
                }
            }        
                  
                    break;
                }
            }
        }

        redBeeIsActive[i] = false;
    }
}

}



/////////////////////////////////////////////BULLET COLLSION////////////////////////////////////
void checkBulletCollision(Sprite bulletSprite, float& bullet_x, float& bullet_y, bool& bullet_exists, Sprite beeSprites[], bool beeIsActive[], bool beeDirection[], bool redBeeIsActive[], Sprite redBeeSprites[], int& score, int maxBees, int maxRedBees,Texture& honeycombTexture,bool beeIsHoneycomb[],Texture& redhoneycombTexture,bool redBeeIsHoneycomb[]) {  

    // Check collision with normal bees
for (int i = 0; i < maxBees; ++i) {
    if (beeIsActive[i] && 
    FloatRect(beeSprites[i].getPosition().x,
        beeSprites[i].getPosition().y,
        beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x,
        beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y
    ).intersects(FloatRect(bullet_x, bullet_y, 32, 32)))  {
            
            Vector2f collisionPosition = beeSprites[i].getPosition();
             if (beeDirection[i]) { // Bee is moving right (coming from the left)
                collisionPosition.x -=20.0f; // Shift honeycomb to the left
            }
            beeSprites[i].setTexture(honeycombTexture);
            beeSprites[i].setScale(1.0f, 1.0f);
            beeSprites[i].setPosition(collisionPosition);
            beeIsActive[i] = false;
            beeIsHoneycomb[i] = true;
            bullet_exists = false;
            score += 100; 
           
            break;
        }
        //////////////////////////////////
        //    hONEYCOMB AND BULLET
        ////////////////////////////////////////////////////////
         if (beeIsHoneycomb[i] && 
    FloatRect(
        beeSprites[i].getPosition().x,
        beeSprites[i].getPosition().y,
        beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x,
        beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y
    ).intersects(FloatRect(bullet_x, bullet_y, 32, 32)))  {
       
            Vector2f collisionPosition = beeSprites[i].getPosition();
            beeIsHoneycomb[i] = false;
            beeSprites[i].setTexture(honeycombTexture); 
            bullet_exists = false;
           break;
        }

    }

    // Check collision with red bees
    for (int i = 0; i < maxRedBees; ++i) {
        if (redBeeIsActive[i] && 
    FloatRect(redBeeSprites[i].getPosition().x,
        redBeeSprites[i].getPosition().y,
        redBeeSprites[i].getTextureRect().width * redBeeSprites[i].getScale().x,
        redBeeSprites[i].getTextureRect().height * redBeeSprites[i].getScale().y
    ).intersects(FloatRect(bullet_x, bullet_y, 32, 32))){

            Vector2f collisionPosition = redBeeSprites[i].getPosition();
            redBeeSprites[i].setTexture(redhoneycombTexture);
            redBeeSprites[i].setScale(1.0f, 1.0f);
            redBeeSprites[i].setPosition(collisionPosition);
            redBeeIsActive[i] = false;
            redBeeIsHoneycomb[i] = true;
            bullet_exists = false;
            score += 1000; 
            break;
    }
    /////////////BULLET AND RED HONEYCOMB////////
    if (redBeeIsHoneycomb[i] && FloatRect(redBeeSprites[i].getPosition().x,redBeeSprites[i].getPosition().y,redBeeSprites[i].getTextureRect().width * redBeeSprites[i].getScale().x,redBeeSprites[i].getTextureRect().height * redBeeSprites[i].getScale().y)
    .intersects(FloatRect(bullet_x, bullet_y, 32, 32))){
            Vector2f collisionPosition = redBeeSprites[i].getPosition();
            redBeeIsHoneycomb[i] = false;
            redBeeSprites[i].setTexture(redhoneycombTexture); 
            bullet_exists = false;
           break;
        }
    }

    




    
}



////////////////////////////////RANDOM HONEYCOMB COLLSIONS///////////////////////////////////////////////////////////////
void checkHoneycombBulletCollision(Sprite honeycombSprites[], bool honeycombActive[], int honeycombCount, float& bullet_x, float& bullet_y, bool& bullet_exists,bool beeIsActive[], bool beeDirection[] ,int maxBees,Sprite beeSprites[], int beeDescent) {
    // Check collision with honeycombs
    for (int i = 0; i < honeycombCount; ++i) {
        if (honeycombActive[i] &&
            FloatRect(honeycombSprites[i].getPosition().x,honeycombSprites[i].getPosition().y,honeycombSprites[i].getTextureRect().width * honeycombSprites[i].getScale().x,honeycombSprites[i].getTextureRect().height * honeycombSprites[i].getScale().y
            ).intersects(FloatRect(bullet_x, bullet_y, 32, 32))) {
            honeycombActive[i] = false;  // Deactivate the honeycomb
            bullet_exists = false;      // Remove the bullet
            break;                      
        }
    }
   /////////////////////////////RANDOM COMB +BEE COLLISION /////////////////////////////////////////
    for (int i = 0; i < maxBees; ++i) {
        if (!beeIsActive[i]) continue;  // Skip inactive bees
        // Check for collision with honeycomb
        for (int j = 0; j < honeycombCount; ++j) {
            if (!honeycombActive[j]) continue;  // Skip inactive honeycombs

            // If a bee collides with a honeycomb, reverse its direction and move downward
            if (FloatRect(
                    beeSprites[i].getPosition().x,
                    beeSprites[i].getPosition().y,
                    beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x,
                    beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y
                ).intersects(FloatRect(honeycombSprites[j].getPosition().x,honeycombSprites[j].getPosition().y,honeycombSprites[j].getTextureRect().width * honeycombSprites[j].getScale().x,honeycombSprites[j].getTextureRect().height * honeycombSprites[j].getScale().y
                ))) {

                // Reflect the bee by reversing its direction and moving it down
                beeDirection[i] = !beeDirection[i];
                beeSprites[i].move(0, beeDescent);  // Move the bee downward slightly to avoid stuck state
                break;  // Stop checking further collisions for this bee
            }
        }
    }

}


////////////////////////////////////////HONEYCOMB/////////////////////////////////////////////////////////
void handleHoneycombCollision(Sprite beeSprites[], bool beeIsActive[], bool beeDirection[],
                               Sprite redBeeSprites[], bool redBeeIsActive[], bool redBeeDirection[],
                               const int maxBees, const int maxRedBees, int beeDescent, bool redBeeIsHoneycomb[],bool beeIsHoneycomb[]) {

//////////////////////////////////////
//      Yellow COMB Collision      //
////////////////////////////////////                                
    for (int i = 0; i < maxBees; ++i) {
        if (!beeIsActive[i]) continue;

    // Check collision with honeycomb
    for (int j = 0; j < maxBees; ++j) {
            if (!beeIsHoneycomb[j]) continue;

    // Detect collision between active bee and honeycomb
    if (FloatRect(
        beeSprites[i].getPosition().x,
        beeSprites[i].getPosition().y,
        beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x,
        beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y
    ).intersects(FloatRect(
        beeSprites[j].getPosition().x,
        beeSprites[j].getPosition().y,
        beeSprites[j].getTextureRect().width * beeSprites[j].getScale().x+5,
        beeSprites[j].getTextureRect().height * beeSprites[j].getScale().y
    ))) {
                beeDirection[i] = !beeDirection[i]; // Reverse direction
                beeSprites[i].move(0, beeDescent);  // Move downward slightly
                break; // Stop checking further collisions for this bee
            }
        }
    }

    

  //////////////////////////////////////////////
 //        RED COMB Collision                //
//////////////////////////////////////////////
    for (int i = 0; i < maxBees; ++i) {
        if (!beeIsActive[i]) continue;

        // Check collision with honeycomb
        for (int j = 0; j < maxBees; ++j) {
            if (!redBeeIsHoneycomb[j]) continue;

            // Detect collision between active bee and red honeycomb
            if (FloatRect(
        beeSprites[i].getPosition().x,
        beeSprites[i].getPosition().y,
        beeSprites[i].getTextureRect().width * beeSprites[i].getScale().x,
        beeSprites[i].getTextureRect().height * beeSprites[i].getScale().y
    ).intersects(FloatRect(
        redBeeSprites[j].getPosition().x,
        redBeeSprites[j].getPosition().y,
        redBeeSprites[j].getTextureRect().width * redBeeSprites[j].getScale().x+5,
        redBeeSprites[j].getTextureRect().height * redBeeSprites[j].getScale().y
    ))) {
                beeDirection[i] = !beeDirection[i]; // Reverse direction
                beeSprites[i].move(0, beeDescent);  // Move downward slightly
                break; // Stop checking further collisions for this bee
            }
        }
    }
}

void updateHummingbird(
    Sprite& hummingbirdSprite, bool& hummingbirdActive, 
    float& hummingbirdX, float& hummingbirdY, 
    float& hummingbirdSpeedX, float& hummingbirdSpeedY,
    bool& hummingbirdIsSick, Clock& hummingbirdSickClock, 
    const float hummingbirdSickDuration, int& points, 
    Sprite honeycombSprites[], bool honeycombActive[], 
    const int honeycombCount, const int resolutionX, 
    const int resolutionY, Clock& honeycombDestroyClock, 
    const float honeycombDestroyDelay
) {
    // If the Hummingbird is sick, manage its recovery
    if (hummingbirdIsSick) {
        if (hummingbirdSickClock.getElapsedTime().asSeconds() >= hummingbirdSickDuration) {
            hummingbirdIsSick = false; // Hummingbird recovers
            hummingbirdSprite.setColor(Color::White); // Reset color
        }
        return; // Skip update while sick
    }

    // Search for an active honeycomb
    bool honeycombFound = false;
    float targetX = hummingbirdX;
    float targetY = hummingbirdY;

    // Find the first active honeycomb
    for (int i = 0; i < honeycombCount; ++i) {
        if (honeycombActive[i]) {
            targetX = honeycombSprites[i].getPosition().x;
            targetY = honeycombSprites[i].getPosition().y;
            honeycombFound = true;
            break; // Stop as soon as we find one active honeycomb
        }
    }

    // If a honeycomb is found, move towards it
    if (honeycombFound) {
        // Calculate the direction to the honeycomb
        float dx = targetX - hummingbirdX;
        float dy = targetY - hummingbirdY;
        float distance = std::sqrt(dx * dx + dy * dy); // Calculate distance

        if (distance > 0) {
            // Normalize the direction vector
            dx /= distance;
            dy /= distance;

            // Move the Hummingbird toward the honeycomb
            hummingbirdX += dx * hummingbirdSpeedX;
            hummingbirdY += dy * hummingbirdSpeedY;
        }
    } else {
        // If no honeycomb is found, move randomly
        hummingbirdX += hummingbirdSpeedX;
        hummingbirdY += hummingbirdSpeedY;
    }

    // Reflect from screen borders
    if (hummingbirdX <= 0 || hummingbirdX + hummingbirdSprite.getTextureRect().width >= resolutionX) {
        hummingbirdSpeedX = -hummingbirdSpeedX; // Reverse horizontal direction
    }
    if (hummingbirdY <= 0 || hummingbirdY + hummingbirdSprite.getTextureRect().height >= resolutionY) {
        hummingbirdSpeedY = -hummingbirdSpeedY; // Reverse vertical direction
    }

    // Update Hummingbird position
    hummingbirdSprite.setPosition(hummingbirdX, hummingbirdY);

    // Destroy honeycombs after the delay
    if (honeycombDestroyClock.getElapsedTime().asSeconds() >= honeycombDestroyDelay) {
        for (int i = 0; i < honeycombCount; ++i) {
            // Create the collision rectangle for both the hummingbird and the honeycomb
            
            // Check if the bounding boxes intersect

            if (honeycombActive[i] && FloatRect(hummingbirdX,
             hummingbirdY,
              hummingbirdSprite.getTextureRect().width,
               hummingbirdSprite.getTextureRect().height)
             .intersects(FloatRect(honeycombSprites[i].getPosition().x,
              honeycombSprites[i].getPosition().y,
               honeycombSprites[i].getTextureRect().width, 
               honeycombSprites[i].getTextureRect().height)
            )){
                // Destroy the honeycomb and award points
                honeycombActive[i] = false; // Mark the honeycomb as destroyed
                points += 100; // Add points for the destruction
                honeycombDestroyClock.restart(); // Reset the timer for the next destruction
                break; // Only destroy one honeycomb per delay
            }
            







        }
    }
}




void handleHummingbirdSpray(
    Sprite& hummingbirdSprite, bool& hummingbirdIsSick, 
    Clock& hummingbirdSickClock
) {
    if (!hummingbirdIsSick) {
        hummingbirdIsSick = true;
        hummingbirdSickClock.restart(); // Start the sick timer
        hummingbirdSprite.setColor(Color::Green); // Change color to indicate sickness
    }
}

void handleHummingbirdBulletCollision(
    Sprite& hummingbirdSprite, bool& hummingbirdIsSick, 
    Clock& hummingbirdSickClock, Sprite bulletSprite, 
    float bullet_x, float bullet_y, bool& bullet_exists,float& hummingbirdX, float& hummingbirdY
) {
    // Check if the Hummingbird collides with the bullet
   if (FloatRect(hummingbirdX,
                hummingbirdY,
                hummingbirdSprite.getTextureRect().width,
               hummingbirdSprite.getTextureRect().height)
             .intersects (FloatRect(bullet_x, bullet_y, 32, 32))) {
        // If the Hummingbird is hit by a bullet
        handleHummingbirdSpray(hummingbirdSprite, hummingbirdIsSick, hummingbirdSickClock); // Make her sick
        bullet_exists = false; // Remove the bullet
    }
}


